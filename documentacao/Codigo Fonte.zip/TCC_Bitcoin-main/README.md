# Bitcoin_Prediction

Mineração de dados para previsão do fechamento do Bitcoin.

Para a execução do programa é necessário o arquivo de configuração .ini dentro da pasta principal.
